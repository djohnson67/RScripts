nums <- rnorm( 3 )

cat( "Random Normal Distribution:", nums, "\n\n" )