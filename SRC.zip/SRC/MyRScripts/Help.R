help( "color" )

??color

plo