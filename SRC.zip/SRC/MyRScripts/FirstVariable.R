name <- "Username"

name <- "Mike McGrath"

print( name )