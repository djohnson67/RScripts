nums <- c( 1:59 )

cat( "My Lucky Numbers:", sample( nums, 6 ), "\n\n" )