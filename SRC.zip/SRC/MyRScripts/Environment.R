iso.codes <- list( "United Kingdom"="UK",
              "United States of America" = "US",
              France="FR", Germany="DE" )
iso.japan <- "JP"
iso.china <- "CN"

ls( )

rm( iso.japan, iso.china )
ls( )