large <- 5
small <- 2

print( paste( "Addition:", large + small ) )
print( paste( "Subtraction:", large - small ) )
print( paste( "Multiplication:", large * small ) )

print( paste( "Division:", large / small ) )
print( paste( "Integer Division:", large %/% small ) )

print( paste( "Exponentiation:", large ^ small ) )

print( paste( "Remainder:", large %% small ) )