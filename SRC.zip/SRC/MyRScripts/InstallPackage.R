install.packages( "ggplot2", dependencies=TRUE )

library( ggplot2 )

help( qplot )